package com.example.flutter_fuja

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
