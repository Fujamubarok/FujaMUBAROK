import 'package:flutter/material.dart';
import 'package:flutter_fuja/dasboard.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: DashBoard(),
  ));
}
