import 'package:flutter/material.dart';

List datainstax = [
  {
    "id": 1,
    "war": Color(0xff70b1a1),
    "img": "InstaxMini7plus_1.png",
    "tag": "Limited Edition",
    "name": "Mini Mint 7+",
    "price": " 49.90",
    "mul_img": [
      "InstaxMini7plus_1.png",
      "InstaxMini7plus_2.png",
      "InstaxMini7plus_3.png",
      "InstaxMini7plus_4.png",
      "InstaxMini7plus_5.png"
    ],
  },
  {
    "id": 2,
    "war": Colors.blue.shade100,
    "img": "InstaxMini7plus_2.png",
    "tag": "Limited Edition",
    "name": "Mini Blue 7+",
    "price": " 50.90",
    "mul_img": [
      "InstaxMini7plus_1.png",
      "InstaxMini7plus_2.png",
      "InstaxMini7plus_3.png",
      "InstaxMini7plus_4.png",
      "InstaxMini7plus_5.png"
    ],
  },
  {
    "id": 3,
    "war": Color(0xffB0463C),
    "img": "InstaxMini7plus_3.png",
    "tag": "Limited Edition",
    "name": "Mini Choral 7+",
    "price": " 51.90",
    "mul_img": [
      "InstaxMini7plus_1.png",
      "InstaxMini7plus_2.png",
      "InstaxMini7plus_3.png",
      "InstaxMini7plus_4.png",
      "InstaxMini7plus_5.png"
    ],
  },
  {
    "id": 4,
    "war": Color(0xfffcf9496),
    "img": "InstaxMini7plus_4.png",
    "tag": "Limited Edition",
    "name": "Mini Pink 7+",
    "price": " 52.90",
    "mul_img": [
      "InstaxMini7plus_1.png",
      "InstaxMini7plus_2.png",
      "InstaxMini7plus_3.png",
      "InstaxMini7plus_4.png",
      "InstaxMini7plus_5.png"
    ],
  },
  {
    "id": 5,
    "war": Color(0xff855f8c),
    "img": "InstaxMini7plus_5.png",
    "tag": "Limited Edition",
    "name": "Mini Lavender 7+",
    "price": " 53.90",
    "mul_img": [
      "InstaxMini7plus_1.png",
      "InstaxMini7plus_2.png",
      "InstaxMini7plus_3.png",
      "InstaxMini7plus_4.png",
      "InstaxMini7plus_5.png"
    ],
  }
];
